const Task = require("../models/Task");

exports.create = async (req, res) => {
  const task = new Task({ ...req.body, user: req.user.id });
  await task.save();
  res.status(201).json(task);
};

exports.list = async (req, res) => {
  const tasks = await Task.find({ user: req.user.id });
  res.json(tasks);
};

exports.update = async (req, res) => {
  const task = await Task.findOneAndUpdate(
    { _id: req.params.id, user: req.user.id },
    req.body,
    { new: true }
  );
  res.json(task);
};

exports.remove = async (req, res) => {
  await Task.findOneAndDelete({ _id: req.params.id, user: req.user.id });
  res.json({ msg: "Tarefa deletada" });
};