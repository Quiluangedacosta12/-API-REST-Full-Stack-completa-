const express = require("express");
const auth = require("../middleware/auth");
const { create, list, update, remove } = require("../controllers/taskController");

const router = express.Router();

router.use(auth);

router.post("/", create);
router.get("/", list);
router.put("/:id", update);
router.delete("/:id", remove);

module.exports = router;